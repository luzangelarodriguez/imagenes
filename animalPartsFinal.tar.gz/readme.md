Animal Parts Dataset
====================

For additional information visit the project website:
www.robots.ox.ac.uk/~vgg/data/animal_parts

Directory information:
----------------------

imdb-animalParts-eye.mat; imdb-animalParts-foot.mat
	- eye/foot annotations in compact MATLAB imdb structures
	- structure reference:
		- imdb.images - image database
			- imdb.images.name - image filename
			- imdb.images.set  - image set (1-train,2-test)
			- imdb.images.id   - unique id of an image - identifies bounding boxes present in the image (imdb.bbx.imageId)
		- imdb.bbx    - bounding box database
			- imdb.bbx.imageId - points to the image id containing a given bounding box
			- imdb.bbx.class - animal class of a given box
			- imdb.bbx.id    - unique id of a box - identifies keypoints peresent inside the bounding box
			- imdb.bbx.set   - box set (1-train,2-test)
			- imdb.bbx.loc   - location of the box (xmin,ymin,xmax,ymax)
		- imdb.kp - keypoint annotations
			- imdb.kp.boxId - points to the box id containing a given keypoint
			- imdb.kp.pos - location of the keypoint (x,y)
			- imdb.kp.obClass - corresponding animal class
			- imdb.kp.ambiguous - a binary flag indicating whether a keypoint cannot be uniquely assigned to one bounding box 
				- images containing ambiguous keypoints should be skipped during evaluation!
			- imdb.kp.class - keypoint class - contains only "1" for now
		- imdb.classes - information about animal classes
			- imdb.classes.name - wnid of each class
			- imdb.classes.description - imagenet description of each class
			- imdb.classes.ok - the classes that have available annotaions
			- imdb.classes.source - source set of classes as used in [1]
			- imdb.classes.target - target set of classes as used in [1]

xml/eye; xml/foot
	- annotations in the pascal xml format
	- individual xml tags, mostly self explanatory
		- name: imagenet wnid of the given bounding box animal class
		- description: imagenet description of the given bounding box animal class
		- classId: id of the given bounding box animal class
	- please double-check that after parsing the xml files, your dataset is identical to the attached matlab imdb structures

sourceClasses.txt; targetClasses.txt
	- class ids of the source and target classes as used in [1]

classMapDescription.txt; classMapWNID.txt
	- the mapping between the original ImageNet classes and the ones used in [1]
	- classMapWNID.txt - the mapping between WNIDS
	- classMapDescription.txt - the mapping between descriptions of WNIDS (the lines between the two files correspond)
	- each line starts with a binary flag indicating whether the original class was altered followed by a pair "original imagenet class", "new class"

readme.md
	- this file

References:
-----------
[1] I Have Seen Enough: Transferring Parts Across Categories, D. Novotny and D. Larlus and A. Vedaldi, Proceedings of the British Machine Vision Conference (BMVC), 2016